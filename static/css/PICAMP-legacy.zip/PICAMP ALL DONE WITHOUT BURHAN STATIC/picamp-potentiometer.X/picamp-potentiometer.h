/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  

#include <xc.h> // include processor files - each processor file is guarded.  
#ifndef POTENTIOMETER_H
#define POTENTIOMETER_H

typedef enum {
  ADC_AN00 = 0b0000,
  ADC_AN01 = 0b0001,
  ADC_AN02 = 0b0010,
  ADC_AN03 = 0b0011,
  ADC_AN04 = 0b0100,
  ADC_AN05 = 0b0101,
  ADC_AN06 = 0b0110,
  ADC_AN07 = 0b0111,
  ADC_AN08 = 0b1000,
  ADC_AN09 = 0b1001,
  ADC_AN10 = 0b1010,
  ADC_AN11 = 0b1011,
  ADC_AN12 = 0b1100,
  ADC_AN13 = 0b1101,
  ADC_CVREF = 0b1110, // CVREF
  ADC_FXREF = 0b1111,  // Fixed Ref (0.6V fixed voltage reference)
  // PIC16F1829
  ADC_16F_AN00 = 0b00000,
  ADC_16F_AN01 = 0b00001,
  ADC_16F_AN02 = 0b00010,
  ADC_16F_AN03 = 0b00011,
  ADC_16F_AN04 = 0b00100,
  ADC_16F_AN05 = 0b00101,
  ADC_16F_AN06 = 0b00110,
  ADC_16F_AN07 = 0b00111,
  ADC_16F_AN08 = 0b01000,
  ADC_16F_AN09 = 0b01001,
  ADC_16F_AN10 = 0b01010,
  ADC_16F_AN11 = 0b01011,
  ADC_16F_TEMP = 0b11101,
  ADC_16F_DACO = 0b11110,
  ADC_16F_FVRB = 0b11111,
} ADCChannelSelect;

int __get_pod_data();
void __init_adc(ADCChannelSelect analogPin);

void populate_step_array(int *array, int size, int potLimit);
void init_pot(ADCChannelSelect port, volatile unsigned char* reg);
int read_potQentiometer(void);

#endif
