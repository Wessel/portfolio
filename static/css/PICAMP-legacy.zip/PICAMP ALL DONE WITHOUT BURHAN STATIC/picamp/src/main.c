/* main.c */

#include "../include/config.h"

#include "../include/initialisation.h"
#include "../include/rotary_encoder.h"
#include "../include/potentiometer.h"
#include "../include/HCMS2913.h"

#define MessageSize 12 //size ofir message
#define IRR PORTBbits.RB0 //infra red reciever
#define LED1 PORTAbits.RA0
#define LED2 PORTAbits.RA1
#define LED3 PORTAbits.RA2
#define LED4 PORTAbits.RA3


char selLoadString[8] = "SEL.  00";
char volLoadString[8] = "VOL. 000";
char volumeBuffer[40];
char selectBuffer[40];


//screen 1, right side
#define RESET_1   PORTCbits.RC2
#define CENABLE_1 PORTCbits.RC4 
#define BLANK_1   PORTCbits.RC6
#define RSELECT_1 PORTCbits.RC7

#define RESET_PINNUM   2
#define CENABLE_PINNUM 4 
#define BLANK_PINNUM   6
#define RSELECT_PINNUM 7

//screen 2, left side
#define RESET_2   PORTDbits.RD2
#define CENABLE_2 PORTDbits.RD4 
#define BLANK_2   PORTDbits.RD6
#define RSELECT_2 PORTDbits.RD7

//global variables
int dataBuffer = 0; //data buffer
char IRBF = 0; //infrared buffer full flag
int data = 0;
char ircount = 0;


//todo(wessel): Remove global
char count = 0;

// Function declarations
void pic_init(void);
void init_gpio(void);

void pic_loop(void);

void main(void) {
    // Do all initialisation here
    pic_init();
    // Start indefinite program loop
    pic_loop();
}

void pic_loop(void) {
    // Initialize potentiometer step array
    int stepArray[LED_AMOUNT] = {0};
    populate_step_array(stepArray, LED_AMOUNT, POT_LIMIT);
    short calcvolume = 0;
    int result = 0;

    while (1) {
        HCMS_load_word(selLoadString, selectBuffer, &PORTD, CENABLE_PINNUM);
        HCMS_load_word(volLoadString, volumeBuffer, &PORTC, CENABLE_PINNUM);

        if (IRBF) {
            if (data == 0b010010010000) {
                //                LED1 = 0;
                count = 0;
            }
            if (data == 0b010100001000) {
                //                LED2 = 0;
                count = 1;
            }
            if (data == 0b010010100000) {
                //                LED3 = 0;
                count = 3;
            }
            if (data == 0b010010001000) {
                //                LED4 = 0;
                count = 4;
            }
            if (data == 0b010100100000) { //volume up
                //                LED1 = 0;
                //                LED2 = 0;
                result++;
            }
            if (data == 0b010100010000) { //volume down
                //                LED3 = 0;
                //                LED4 = 0;
                result--;
            }

            IRBF = 0;
        }



        // Parse result from potentiometer
        result = read_potentiometer();

        // Loop through all `stepArray`, check if the output of the potmeter
        // (on `ADRES`) falls inbetween the steps - `DEADZONE`, if so execute
        // An OR/AND bitshift operation in order to turn on the corresponding
        // LED on `PORTA`.
        //        for (int i = 0; i < LED_AMOUNT; i++) {
        //            if (result > (stepArray[i] - DEADZONE)) {
        //                PORTA = (unsigned char) (PORTA & ~(1 << i));
        //            } else if (result <= (stepArray[i] - DEADZONE)) {
        //                PORTA = (unsigned char) (PORTA | (1 << i));
        //            }
        //        }

        calcvolume = result / POT_STEP_AMOUNT;

        if (calcvolume > 100) {
            calcvolume = 100;
        }
        if (calcvolume < 0) {
            calcvolume = 0;
        }

        selLoadString[6] = '0' + count / 10;
        selLoadString[7] = '0' + (count % 10);

        volLoadString[5] = '0' + (char) (calcvolume / 100);
        volLoadString[6] = '0' + (char) (calcvolume / 10 > 9 ? 0 : calcvolume / 10);
        volLoadString[7] = '0' + (char) (calcvolume % 10);

    }
}

void pic_init(void) {
    // ADCConfig adc_config        = { ADC_ON, ADC_RIGHT, ADC_AN07, ADC_FOSC02,
    //                                 VREF_PLUSPIN, VREF_MINPIN, ADC_IN_PROGRESS };
    OscillatorConfig osc_config = {INTERNAL_CLK, MHZ008, INTERNAL_FOSC};
    InterruptConfig int_config = {GIE_ENABLED, EINT_ENABLED, PEIE_ENABLED,
        T0INT_ENABLED, RBINT_ENABLED, FALLING_EDGE}; // was rising edge

    // PinConfig pin_config[] = {
    //   { &TRISA, &PORTA, &ANSEL, OUTPUT, DIGITAL }, // LEDs
    //   { &TRISB, &PORTB, &ANSELH, INPUT, DIGITAL }, // Rotary encoder A
    //   { &TRISBbits.TRISB5, &PORTBbits.RB5, &ANSELH,   INPUT, DIGITAL }, // Rotary encoder B
    //   { &TRISEbits.TRISE2, &PORTE, &ANSELH, INPUT, ANALOG } // Potmeter
    // };
    // init_gpio2(pin_config);

    init_osc(osc_config);
    init_int(int_config);
    init_gpio();
    // init_adc(adc_config);
    init_pot(ADC_AN07, TRISEbits.TRISE2);

    HCMS_spi_init(MST_OSC_DIV_04, SMP1_SDI_END, CKP0_CPOL0_IDLE_LOW, CKE1_CPHA0_TRSMIT_ACT2IDL);
    HCMS_init(&PORTC, RESET_PINNUM, CENABLE_PINNUM, RSELECT_PINNUM);
    HCMS_init(&PORTD, RESET_PINNUM, CENABLE_PINNUM, RSELECT_PINNUM);
}

// #[initialisation:gpio]
// todo(wessel): Make init_gpio() from initialisation.c work

void init_gpio(void) {
    TRISC = 0;
    TRISD = 0;
    PORTC = 0;
    PORTD = 0;
    // LED => output
    TRISA = OUTPUT;
    PORTA = OFF;
    // Infrared => input
    TRISBbits.TRISB0 = INPUT;
    // Rotary => input
    TRISBbits.TRISB4 = INPUT;
    TRISBbits.TRISB5 = INPUT;
    // Potentiometer => input
    // TRISEbits.TRISE2 = INPUT;
    // Set all pins to digital
    ANSEL = 0;
    ANSELH = 0;
    // ANSELbits.ANS7 = 1;
}

// #[routine:interrupt_service]

void __interrupt() isr(void) {
    if (INTCONbits.INTF == INT_OCCURED) {
        TMR2 = 0;
        TMR2ON = 1;
        TMR1 = 0;
        TMR1ON = 1;
        INTF = 0;
    }

    if (TMR2IF) {
        dataBuffer = dataBuffer << 1;
        if (!IRR) {
            dataBuffer |= 0b1;
        }
        ircount++;
        TMR2ON = 0;
        if (ircount >= MessageSize) {
            data = dataBuffer;
            dataBuffer = 0;
            ircount = 0;
            IRBF = 1;
        }
        TMR2IF = 0;
    }//TMR2IF

    if (TMR1IF) { //timeout / reset
        ircount = 0;
        dataBuffer = 0;
        TMR1ON = 0;
        TMR1 = 0;
        //TEMP reset
        LED1 = 1;
        LED2 = 1;
        LED3 = 1;
        LED4 = 1;
        //
        TMR1IF = 0;
    } //TMR1IF

    if (INTCONbits.RBIF == INT_OCCURED) {
        // Parse rotary changes into `count`, shift it into `PORTA`
        parse_rotary(REA, REB, &count, LED_AMOUNT, 0);
        //        PORTA = (unsigned char) (~(1 << count));

        // Clear the Port B change interrupt flag
        INTCONbits.RBIF = INT_AWAITING;
        INTCONbits.INTF = INT_AWAITING;
        // INTCONbits.INTF = INT_AWAITING;
    }
}
