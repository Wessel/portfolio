#ifndef POTENTIOMETER_H
#define POTENTIOMETER_H

typedef enum {
  ADC_AN00 = 0b0000,
  ADC_AN01 = 0b0001,
  ADC_AN02 = 0b0010,
  ADC_AN03 = 0b0011,
  ADC_AN04 = 0b0100,
  ADC_AN05 = 0b0101,
  ADC_AN06 = 0b0110,
  ADC_AN07 = 0b0111,
  ADC_AN08 = 0b1000,
  ADC_AN09 = 0b1001,
  ADC_AN10 = 0b1010,
  ADC_AN11 = 0b1011,
  ADC_AN12 = 0b1100,
  ADC_AN13 = 0b1101,
  ADC_CVREF = 0b1110, // CVREF
  ADC_FXREF = 0b1111  // Fixed Ref (0.6V fixed voltage reference)
} ADCChannelSelect;

int __get_pod_data();
void init_pot(ADCChannelSelect port, volatile unsigned char* reg);
void populate_step_array(int *array, int size, int potLimit);
int read_potentiometer(void);

#endif
