
DEL /F /Q output